//
//  Selling_infoModel.h
//
//  http://www.cnblogs.com/YouXianMing/
//  https://github.com/YouXianMing
//
//  Copyright (c) YouXianMing All rights reserved.
//


#import <Foundation/Foundation.h>

@interface Selling_infoModel : NSObject

@property (nonatomic, strong) NSMutableArray *  infoArray;
-(NSString *)soldTime;
-(NSString *)backTime;

/**
 *  Init the model with dictionary
 *
 *  @param dictionary dictionary
 *
 *  @return model
 */
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

